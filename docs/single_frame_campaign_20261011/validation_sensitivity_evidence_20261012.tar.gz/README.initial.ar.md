# تحليل وصفي مستقل لحساسية validation

المصدر المثبت: `work/search_phase_labelled_20261012.csv`، SHA256:
`9d0ba585e55cc6e9694b956b974e65f6e8da7a7210c402dd1a0de76d40d15242`.

`analyse.py` لا يستورد المحرك أو مولد الإشارات؛ يستخدم مكتبة Python القياسية
ويعيد بناء هويات الشبكة المحدودة من مواصفاتها الأصلية. لا يصل إلى أعمدة
`selection_disposition/reasons/disposition_partition/validation_score`؛ يختبر
منع الوصول إليها بحالة PoisonRow. لا يفتح أي artifact أو ملف اختيار أو حالة
للحملة. مسار artifact المنقول في المصفوفة مرجع نصي فقط.

`verify.py` تنفيذ منفصل لا يستورد المولد، ويطابق كل نقطة علمية ومحاولة وحافة
بالمصدر، ثم يعيد حساب التوزيعات الوصفية فقط. الاختبارات اصطناعية تخص صحة
الأداة ولا تدخل في نتائج البحث.

نُفذت الاختبارات قبل كل مرحلة؛ السجلات محفوظة هنا:

```bash
cd work/validation_sensitivity_20261012
PYTHONDONTWRITEBYTECODE=1 ../../.venv/bin/python -m unittest -v test_analyse
PYTHONDONTWRITEBYTECODE=1 ../../.venv/bin/python -m unittest -v test_verify
```

أوامر الحساب المنفذة في هذه النسخة، من جذر المستودع:

```bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python work/validation_sensitivity_20261012/analyse.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python work/validation_sensitivity_20261012/verify.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python work/validation_sensitivity_20261012/summarise.py
```

كل أداة ترفض استبدال مخرجاتها القائمة. لإعادة الحساب في نسخة نظيفة، انقل
المصدر المثبت والكود والاختبارات إلى المسارات نفسها دون المخرجات الموجودة؛
لا تحذف الأدلة الأصلية ولا تعِد تشغيل حملة أو backtest. المولد يقصر كتابته
على مجلده التشغيلي هذا. يتطلب الأمر وجود مصدر الشبكة المجمد المطابق في
`research_campaign/strategies.py` للبصمة فقط؛ لا يستورده أو يشغله.

المخرجات:

- `declared_grid_points.csv`: كل32 نقطة معلنة لكل مجموعة، مع measured/cache/missing.
- `scientific_points.csv`: هوية علمية واحدة لكل نقطة مختلفة، دون مضاعفة aliases.
- `adjacent_comparisons.csv`: جميع104,000 حافة وتصنيف التكرار أو الخمول أو المقارنة.
- `group_metric_summary.csv`: توزيعات المقاييس الأربعة لكل مجموعة مستقلة.
- `validation_sensitivity.json`: التفاصيل الكاملة للشبكة والجوار والتوزيعات.
- `receipt.json`: بصمات المولد والمدخل والمخرجات وقيود النطاق.
- `independent_verification.json`:1,762,579 فحصًا من المصدر إلى المصفوفات.
- `REPORT.ar.md` و`DESCRIPTIVE_FINDINGS.ar.md`: الشرح والملخص الوصفي العربي.
- `delivery_manifest.json`: بصمات ملفات التسليم؛ لا يتضمن نفسه.

PnL بوحدات حساب مفترضة. نقاط المعلمات ليست صفقات مستقلة؛ لا تجمع هذه
الأداة الأرباح أو الصفقات لتكوين استراتيجية. لا اختيار أو إعادة ترتيب أو
تعديل قبول، ولا تغيير للنتائج النهائية أو الأصول المجمدة أو اللوحة.
